extends RefCounted
func damage(): return 10
